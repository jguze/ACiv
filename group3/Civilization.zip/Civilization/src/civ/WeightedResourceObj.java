/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package civ;

import java.io.Serializable;


public class WeightedResourceObj implements Serializable {
    public int prodWeight;
    public int foodWeight;
    public int sciWeight;
    
    public WeightedResourceObj(int p, int f, int s) {
        prodWeight = p;
        foodWeight = f;
        sciWeight = s;
    }
}

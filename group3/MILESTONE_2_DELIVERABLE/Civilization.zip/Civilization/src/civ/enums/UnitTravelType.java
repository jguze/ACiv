package civ.enums;

public enum UnitTravelType {
    GROUND,
    SEA,
    AIR
}

package civ.enums;

public enum TerrainBonusType {
    BUFFALO,
    COAL,
    FISH,
    FRUIT,
    FURS,
    GEMS,
    GOLD,
    IRON,
    IVORY,
    NONE,
    OASIS,
    OIL,
    PEAT,
    PHEASANT,
    SILK,
    SPICE,
    WHALE,
    WHEAT,
    WINE
}


/**
 * civ.maps is a package that deals with map generation and parsing map files.
 * It can be used to gather information about the maps before generating them (which we use
 * in the setup screen).
 */
package civ.maps;
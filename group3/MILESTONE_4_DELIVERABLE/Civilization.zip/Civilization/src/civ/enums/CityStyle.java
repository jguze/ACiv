package civ.enums;

public enum CityStyle {
    EUROPEAN,
    CLASSICAL,
    INDUSTRIAL,
    MODERN,
    POSTMODERN,
    ASIAN,
    TROPICAL
}

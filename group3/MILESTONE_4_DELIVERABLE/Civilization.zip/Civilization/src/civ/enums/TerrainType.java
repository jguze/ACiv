package civ.enums;

public enum TerrainType {
    DESERT,
    FOREST,
    GLACIER,
    GRASSLAND,
    HILLS,
    JUNGLE,
    MOUNTAINS,
    OCEAN,
    PLAINS,
    SWAMP,
    TUNDRA
}

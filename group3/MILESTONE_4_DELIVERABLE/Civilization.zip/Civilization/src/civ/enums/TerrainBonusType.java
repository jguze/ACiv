package civ.enums;

public enum TerrainBonusType {
    BUFFALO,
    COAL,
    FISH,
    FRUIT,
    FURS,
    GAME,
    GEMS,
    GOLD,
    IRON,
    IVORY,
    NONE,
    OASIS,
    OIL,
    PEAT,
    PHEASANT,
    SHIELD,
    SILK,
    SPICE,
    WHALE,
    WHEAT,
    WINE
}

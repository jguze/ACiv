
/**
 * civ.sprites is a package that contains the aspects of Civilization pertaining to sprites, colors
 * and other images. It is responsible for parsing in sprite sheets and colors for the mini map
 * upon its instantiation.
 */
package civ.sprites;
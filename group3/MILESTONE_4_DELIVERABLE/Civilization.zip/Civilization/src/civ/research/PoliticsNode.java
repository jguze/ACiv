/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package civ.research;

import civ.enums.UnitType;
import java.util.ArrayList;


class PoliticsNode extends TreeNode {

    public PoliticsNode(ArrayList <UnitType> aU) {
        super(aU);
        turnsToComplete = THIRDLEVELTURNS;
    }

    @Override
    public void researchComplete() {
        this.setResearched(true);
        availableUnits.add(UnitType.DIPLOMAT);
        availableUnits.add(UnitType.PARTISAN);
        availableUnits.add(UnitType.FREIGHT);
        availableUnits.add(UnitType.TRANSPORT);
        
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package civ.research;

/**
 * Basic rootNode of the Tree. Points to all uppermost parent nodes.
 * @author Justin
 */
class RootNode extends TreeNode {

    public RootNode() {
        super();
    }

    @Override
    public void researchComplete() {
        return;
    }

}

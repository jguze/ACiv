/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package civ.research;

import civ.enums.UnitType;
import java.util.ArrayList;


class FlightNode extends TreeNode {

    public FlightNode(ArrayList <UnitType> aU) {
        super(aU);
        turnsToComplete = THIRDLEVELTURNS;
    }

    @Override
    public void researchComplete() {
        this.setResearched(true);
        availableUnits.add(UnitType.FIGHTER);
        availableUnits.add(UnitType.BOMBER);
    }

}

/*
 * Handles combat between units when a collision is detected by the game engine
 */

package civ.engine;

import civ.MapLocation;
import civ.Unit;
import java.util.ArrayList;


public class CombatManager {

    public void collision(Unit selectedUnit, MapLocation enemyUnitLocation) {
       //TODO
    }
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package civ;

import civ.enums.UnitType;
import java.io.Serializable;

public class UnitCreateObj implements Serializable {
    private UnitType unitType;
    private MapLocation unitLocation;

    public UnitCreateObj(UnitType ut, MapLocation mLoc) {
        unitType = ut;
        unitLocation = mLoc;
    }

    public UnitType getUnitType() {
        return unitType;
    }

    public MapLocation getLocation() {
        return unitLocation;
    }
}

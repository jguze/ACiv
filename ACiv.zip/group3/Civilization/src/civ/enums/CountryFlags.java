package civ.enums;

public enum CountryFlags {
    GERMANY,
    CANADA,
    PIRATES,
    CZECH,
    USA,
    TURKEY,
    TAIWAN,
    SWITZERLAND,
    SOMALIA,
    NORWAY,
    JAPAN,
    JAMAICA
}
